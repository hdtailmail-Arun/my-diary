1. Create a free account at github.com and make a NEW repository (e.g. my-diary).
2. Upload ALL files of this folder (including the hidden .github folder) to it.
3. Open the "Actions" tab -> "Build APK" -> wait ~5 minutes for a green tick.
4. Open the finished run -> Artifacts -> download "my-diary-apk" (zip) -> unzip.
5. Copy app-debug.apk to your phone and install it (allow "install unknown apps").
